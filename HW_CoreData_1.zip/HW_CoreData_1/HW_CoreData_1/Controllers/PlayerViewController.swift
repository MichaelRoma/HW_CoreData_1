//
//  PlayerViewController.swift
//  HW_CoreData_1
//
//  Created by Mykhailo Romanovskyi on 18.08.2020.
//  Copyright © 2020 Mykhailo Romanovskyi. All rights reserved.
//

import UIKit

class PlayerViewController: UIViewController {
    
    struct Position {
        static let positions = ["Forward",
                                "Midfielder",
                                "Defender",
                                "Goalkeeper"
        ]
    }
    
    struct Team {
        static let teams = ["Dinamo",
                            "Milan",
                            "Moscow-Dinamo",
                            "GasMias"
        ]
    }
    
    @IBOutlet weak var teamPickerView: UIPickerView!
    @IBOutlet weak var positionPickerView: UIPickerView!
    @IBOutlet weak var selectTeamButton: UIButton!
    @IBOutlet weak var selectPositionButton: UIButton!
    @IBOutlet weak var inputNumberField: UITextField!
    @IBOutlet weak var inputNameField: UITextField!
    @IBOutlet weak var inputNationalityField: UITextField!
    @IBOutlet weak var inputAgeField: UITextField!
    @IBOutlet weak var avatarView: UIImageView!
    @IBOutlet weak var saveButton: UIButton!
    
    private var imagePickerController = UIImagePickerController()
    private var chosenImage: UIImage!
    private var selectedTeam = ""
    private var selectedPosition = ""
    
    var dataManager: CoreDataManager!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        if selectedTeam.isEmpty ||
            selectedPosition.isEmpty ||
            inputNumberField.text?.isEmpty ?? true ||
            chosenImage == nil ||
            inputNameField.text?.isEmpty ?? true ||
            inputNationalityField.text?.isEmpty ?? true ||
            inputAgeField.text?.isEmpty ?? true {
            alertSaveButton()
        } else {
            let context = dataManager.getContext()
            
            let image = dataManager.createObject(from: Image.self)
            image.image = chosenImage
            
            let club = dataManager.createObject(from: Club.self)
            club.name = selectedTeam
            
            let player = dataManager.createObject(from: Player.self)
            player.fullName = inputNameField.text
            player.age = Int16(inputAgeField.text!)!
            player.club = club
            player.image = image
            player.nationality = inputNationalityField.text
            player.position = selectedPosition
            player.playerNumber = inputNumberField.text
            
            dataManager.save(context: context)
            navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func uploadImagePressed(_ sender: Any) {
        present(imagePickerController, animated: true)
    }
    
    @IBAction func selectPositionNuberPressed(_ sender: Any) {
        
    }
    
    @IBAction func selectTeamPressed(_ sender: Any) {
        positionPickerView.isHidden = true
        teamPickerView.isHidden = false
    }
    
    @IBAction func selectPositionPressed(_ sender: Any) {
        teamPickerView.isHidden = true
        positionPickerView.isHidden = false
    }
    
    private func setupUI() {
        
        inputNumberField.inputAccessoryView = createToolBar()
        inputNameField.inputAccessoryView = createToolBar()
        inputNationalityField.inputAccessoryView = createToolBar()
        inputAgeField.inputAccessoryView = createToolBar()
        
        teamPickerView.tag = 0
        positionPickerView.tag = 1
        
        teamPickerView.delegate = self
        teamPickerView.dataSource = self
        positionPickerView.delegate = self
        positionPickerView.dataSource = self
        
        teamPickerView.isHidden = true
        positionPickerView.isHidden = true
        
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
    }
    
    private func createToolBar() -> UIToolbar {
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(keyboardDismiss))
        toolBar.setItems([doneButton], animated: true)
        toolBar.isUserInteractionEnabled = true
        return toolBar
    }
                                                                                               
    private func alertSaveButton() {
        let alert = UIAlertController(title: "Error", message: "Not all fileds have DATA, CHECK IT NOW", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alert, animated: true)
    }
    
    @objc private func keyboardDismiss() {
        view.endEditing(true)
    }
}

extension PlayerViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        pickerView.tag == 0 ? Team.teams.count : Position.positions.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        pickerView.tag == 0 ? Team.teams[row] : Position.positions[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView.tag == 0 {
            selectTeamButton.setTitle(Team.teams[row], for: .normal)
            selectedTeam = Team.teams[row]
            teamPickerView.isHidden = true
        } else {
            selectPositionButton.setTitle(Position.positions[row], for: .normal)
            selectedPosition = Position.positions[row]
            positionPickerView.isHidden = true
        }
    }
}

extension PlayerViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else { return }
        chosenImage = image
        avatarView.image = image
        do {
            imagePickerController.dismiss(animated: true, completion: nil)
        }
    }
}
